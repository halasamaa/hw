/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author هلا سمعان
 */
public class developer extends Game{
  
String name ;
String Email;
Game game;

  
    public developer(String name, String Email, Game game) {
        this.name = name;
        this.Email = Email;
        this.game = game;
    }



public void submitGame(Game name){
  if(accepted==true) {
      System.out.println("The game will be published.. *-*");
      
  }
  else
      System.out.println("The game is not acceptable...");
}

public void communicate(){
}
}
    

